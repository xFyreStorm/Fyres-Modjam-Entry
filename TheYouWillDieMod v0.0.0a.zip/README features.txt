
Mod idea: Rougelike mod!

Features:

Traps (Can only be seen within 6 block radius while crouching, does damage to players and hostile mobs that touch it, has small chance to poison, can be disarmed by right clicking, if disarm fails, you take half a heart damage)
Can disable traps in the properties file

Trap types:
    
    Spike Trap - Does 1 heart of damage while touching, 1% chance to poison
    Flame Trap - Sets on fire for 5 seconds

Dungeons spawn 13x as often 

Hostile mobs get levels (+5 hp per level, +5 additional for level 5)
Level 5 mobs get a blessing (Ranged mobs: Hunter or Swamp, Non-ranged Mobs: Warrior or Swamp)

Bows, Axes, and Swords get a random rank and bonus damage, along with a random prefix

Pillars (randomly spawn around world, give blessing when right clicked, i.e. Blessing of the Miner, +25% Mining Speed, pillars of your current blessing will slightly glow and emit particles)
Use x button on pillar to see what blessing they have.

Blessings: 

    Miner - +25% mine speed on stone and iron blocks,
    Lumberjack - +25% mine speed on wooden blocks,
    Warrior - +25% melee damage,
    Hunter - +25% projectile damage,
    Swamp - Attacks will slow enemies,
    Thief - Enemies have a chance to drop gold nuggets,
    Ninja - While sneaking you are invisible and attacks on enemies with full health do double damage,
    Mechanic - You can salvage disarmed traps 50% of the time.
    Alchemist - All potions act like wildcard potions,
    Scout - You can see traps without sneaking,
    Guardian - Take 25% less damage from all sources,
    Vampire - Heal 10% of damage dealt to enemies
    
/currentBlessing command shows your current blessing
    
Mystery potions - each new world you make selects 12 potion types and durations. Find and drink a mystery potion to find out what it does permanently in that world! Wildcard potion always give a random effect.
1 in 10 drop from all mobs, 100% drop rate for level 5 mobs

When a world is created, it is given a random disadvantage. You are told what it is when logging in to a world. Complete world goal to remove disadvantage.

Disadvantages:

    Tougher Mobs - -25% damage to hostile enemies,
    Weak - -25% melee damage,
    Explosive Traps - Traps trigger explosions on failed disarms
    
World Goals: When a world is created, it is given a random goal. Complete the goal to remove the world disadvantage. You then receive a new goal.

/currentGoal command shows your current world goal