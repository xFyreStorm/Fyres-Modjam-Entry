
Mod idea: Rougelike mod!

Features:

Traps (Can only be seen within 6 block radius while crouching, does damage to players and hostile mobs that touch it, has small chance to poison, can be disarmed by right clicking)
Can disable traps in the properties file

Dungeons spawn 13x as often

Hostile mobs get levels (+5 hp per level, +5 additional for level 5)
Level 5 mobs get a blessing (Ranged mobs: Hunter or Swamp, Non-ranged Mobs: Warrior or Swamp)

Bows, Axes, and Swords get a random rank and bonus damage, along with a random prefix

Pillars (randomly spawn around world, give blessing when right clicked, i.e. Blessing of the Miner, +25% Mining Speed, pillars of your current blessing will slightly glow and emit particles)
Use x button on pillar to see what blessing they have.

Blessings: 

    Miner - +25% mine speed on stone and iron blocks,
    Lumberjack - +25% mine speed on wooden blocks,
    Warrior - +25% melee damage,
    Hunter - +25% projectile damage,
    Swamp - Attacks will slow enemies,
    Thief - Enemies have a chance to drop gold nuggets,
    Ninja - While sneaking you are invisible and attacks on enemies with full health do double damage,
    Mechanic - You can salvage disarmed traps 50% of the time
    
/currentBlessing command shows your current blessing
    
Unmarked potions (Each new world you make selects 12 potion types and durations. Drink a mystery potion to find out what it does permanently in that world! Wildcard potion always give a random effect)

When a world is created, it is given a random disadvantage. You are told what it is when logging in to a world.

Disadvantages:

    Tougher Mobs - -25% damage to hostile enemies,
    Weak - -25% melee damage
    