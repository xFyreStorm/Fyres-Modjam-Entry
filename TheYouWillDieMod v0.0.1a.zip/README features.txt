
Mod idea: Rougelike mod! Make Minecraft harder with rougelike features. Adds goals, mystery potions, more dungeons, blessings, world debuffs, and more!

Features:

Press x key to examine objects

Traps (Can only be seen within 6 block radius while crouching, does damage to players and hostile mobs that touch it, has small chance to poison, can be disarmed by right clicking, if disarm fails, you take half a heart damage)
Can disable traps in the properties file

Trap types:
    
    Spike Trap - Does 1 heart of damage while touching, 1% chance to poison
    Flame Trap - Sets on fire for 5 seconds
    
Towers (3 - 8 floors tall of cobble and mossy cobble) spawn around the world, and contain mob spawners and chests

Dungeons spawn 13x as often 

Hostile mobs get levels (+5 hp per level, +5 additional for level 5)
Level 5 mobs get a blessing (Ranged mobs: Hunter or Swamp, Non-ranged Mobs: Warrior or Swamp)

Bows, Axes, and Swords get a random rank and bonus damage, along with a random prefix

Pillars (randomly spawn around world and change current blessing when right clicked, pillars of your current blessing will slightly glow and emit particles)

Examining a pillar or a mob with a blessing with the examine key will tell you what blessing it has.

You get a randomly selected blessing to start with the first time you enter a world.

Blessings: 

    Miner - +25% mine speed on stone and iron blocks,
    Lumberjack - +25% mine speed on wooden blocks,
    Warrior - +25% melee damage,
    Hunter - +25% projectile damage,
    Swamp - Attacks will slow enemies,
    Thief - Enemies have a chance to drop gold nuggets,
    Ninja - While sneaking you are invisible and attacks on enemies with full health do double damage,
    Mechanic - You disarm traps 3x as often and have 2x the chance to salvage disarmed traps,
    Alchemist - All potions act like wildcard potions,
    Scout - You can see traps without sneaking,
    Guardian - Take 25% less damage from all sources,
    Vampire - Heal 10% of damage dealt to enemies
    
/currentBlessing command shows your current blessing
    
Mystery potions - each new world you make selects 12 potion types and durations. Find and drink a mystery potion to find out what it does permanently in that world! Wildcard potion always give a random effect.
1 in 10 drop from all mobs, 100% drop rate for level 5 mobs, they also spawn in dungeon chests

When a world is created, it is given a random disadvantage. You are told what it is when logging in to a world. Complete world goal to remove disadvantage.

Disadvantages:

    Tougher Mobs - -25% damage to hostile enemies,
    Weak - -25% melee damage,
    Explosive Traps - Traps trigger explosions on failed disarms,
    Increased Mob Spawn - +33% hostile mob spawn rate,
    Neverending Rain - Constantly rains,
    Neverending Night - Constantly night
    
World Goals: When a world is created, it is given a random goal. Complete the goal to remove the world disadvantage. You then receive a new goal.

/currentGoal command shows your current world goal

3 Achievements to earn